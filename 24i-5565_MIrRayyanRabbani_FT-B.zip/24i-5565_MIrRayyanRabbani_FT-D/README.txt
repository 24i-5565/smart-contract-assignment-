🏦 FinTech Sepolia Micro-Vault dApp

Course: MG3012 - Blockchain Technology for Business

Assignment 2: Mini dApp - Solidity Smart Contract + HTML/JS Frontend

Semester: BSFT - 5th Semester (Fall 2026)

Instructor: Dr. Usama Arshad

📌 Project Overview

The FinTech Sepolia Micro-Vault dApp is a decentralized application built on the Ethereum Sepolia Testnet. It demonstrates end-to-end Web3 integration between a Solidity smart contract (FinTechVault), a clean HTML/CSS user interface, and the MetaMask browser wallet using Ethers.js (v5).

Users can connect their MetaMask wallet, read real-time state variables from the blockchain, deposit and withdraw virtual vault units, update a public on-chain notice board, and track live transaction hashes with direct links to the Sepolia Etherscan block explorer.

🔗 Live Deployment Details

Blockchain Network: Ethereum Sepolia Testnet (Chain ID: 11155111)

Deployed Contract Address: 0x4c07df1f54FDb063766A0aFc3E1a07eA692dECfC

Sepolia Etherscan Explorer: View Contract on Sepolia Etherscan

(Note: Replace PASTE_YOUR_CONTRACT_ADDRESS_HERE above with your actual deployed contract address from Remix IDE before submitting!)

📂 Folder Structure

MG3012_Assignment2/
├── SmartContract.sol       # Solidity Smart Contract (5 functions: 3 Write, 2 Read)
├── index.html              # Single-page Frontend (HTML5, internal CSS, Ethers.js logic)
├── README.md               # Project documentation and setup guide
└── screenshots/            # Proof of deployment, wallet connection, and transactions
    ├── 1_deployment.png
    ├── 2_connected.png
    └── 3_transaction.png


🧩 Smart Contract Architecture (SmartContract.sol)

The contract is written in Solidity ^0.8.20 and includes 5 core functions (exceeding the minimum 3–5 function requirement with both Read and Write operations):

✍️ Write Functions (State-Changing)

depositFunds(uint256 _amount): Allows the connected user (msg.sender) to deposit virtual units into their personal vault balance and increments totalTransactions.

withdrawFunds(uint256 _amount): Allows the user to withdraw units from their balance (enforces a require check to prevent overdrawing) and increments totalTransactions.

updateNotice(string memory _newNotice): Updates the public on-chain vaultNotice string and increments totalTransactions.

📖 Read Functions (View / Gas-Free)

getMyBalance(): Returns the current unit balance mapped to the caller's wallet address (msg.sender).

getVaultStats(): Returns a tuple containing the current vaultNotice string and the totalTransactions counter.

🌐 Frontend & Bonus Features (index.html)

Complete HTML5 Structure: Incorporates headings (<h1>, <h3>), paragraphs (<p>), lists (<ul>, <li>), anchor links (<a>), interactive buttons (<button>), images (<img>), <style>, and <script> tags.

MetaMask & Ethers.js Integration: Uses ethers.providers.Web3Provider(window.ethereum) to request account access, sign state-changing transactions, and read data from the Sepolia network.

⭐ Bonus UI Feature: Includes a Live Session Activity Log that dynamically records every transaction performed during the session and generates clickable Sepolia Etherscan transaction hash links (https://sepolia.etherscan.io/tx/...).

🚀 How to Run the Project Locally

Prerequisites

A web browser (Chrome, Brave, or Edge) with the MetaMask Extension installed.

MetaMask switched to the Sepolia Test Network and funded with a small amount of SepoliaETH for gas fees.

VS Code with the Live Server extension installed (recommended so window.ethereum is properly injected by the browser).

Setup Steps

Deploy the Smart Contract (if deploying fresh):

Open Remix IDE and load SmartContract.sol.

Compile using Solidity compiler version 0.8.20.

Under Deploy & Run Transactions, select Injected Provider - MetaMask and click Deploy.

Copy the deployed contract address.

Configure the Frontend:

Open index.html in a code editor.

Replace "YOUR_CONTRACT_ADDRESS_HERE" inside the <script> tag with your deployed Sepolia contract address.

Launch the dApp:

Right-click index.html in VS Code and select "Open with Live Server" (or run npx serve in the project directory).

Click 🔗 Connect MetaMask Wallet and approve the connection prompt.

Use the Deposit, Withdraw, and Update Notice buttons to execute transactions on Sepolia and click 🔄 Refresh Contract Data to verify state updates.

📸 Screenshots Included

Inside the screenshots/ directory:

1_deployment.png: Shows SmartContract.sol compiled and deployed on the Sepolia Testnet via Remix IDE.

2_connected.png: Shows the index.html frontend connected to MetaMask with initial blockchain state loaded.

3_transaction.png: Shows a confirmed write transaction with updated state values and the transaction hash logged in the UI.